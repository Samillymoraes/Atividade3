package atividades;

public class Porta {
	
	public String aberta;
	public String cor;
	public Double dimensaoX;
	public Double dimensaoY;
	public Double dimensaoZ;
	
	public void abre() {
		
	}
	
	public void fecha() {
		
	}
	
	public void pinta (String s) {
		
	}
	
	public boolean estaAberta() {
		return true;
		
	}
	
}
