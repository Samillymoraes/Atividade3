package atividades;

public class Pessoa {
	public String nome;
	public Double idade;
	
	public void fazAniversario() {
		
	}

}
