package atividades;

public class Casa {
	public String cor;
	public String porta1;
	public String porta2;
	public String porta3;
	public Pessoa proprietário;
	
	public void pinta (String s) {
		
	}
	
	public int qtdPortasEstaoAbertas() {
		return 0;
		
	}

}
