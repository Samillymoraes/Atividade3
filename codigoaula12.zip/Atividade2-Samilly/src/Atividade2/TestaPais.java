package Atividade2;

public class TestaPais {

	public static void main(String[] args) {
		
		Pais p = new Pais ("BRA", "Brasil", 210000.0, 5544554545.0);
		
		p.vizinhos.add("Argentina");
		p.vizinhos.add("Uruguai");
		p.vizinhos.add("Paraguai");

		

	}

}
