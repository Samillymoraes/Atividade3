package Atividade2;

import java.util.ArrayList;
import java.util.List;

public class Pais {
	
	public String codigo;
	public String nome;
	public Double populacao;
	public Double dimensao;
	public List<String> vizinhos;
	
	public Pais(String novoCodigo,String novoNome,Double novaPopulacao,Double novaDimensao) {
		
		this.codigo = novoCodigo;
		this.nome = novoNome;
		this.populacao = novaPopulacao;
		this.dimensao = novaDimensao;
		this.vizinhos = new ArrayList<String>();
		
	}
	

}
