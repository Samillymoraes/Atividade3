package Atividade2;

public class Triangulo {
	public Ponto ponto1;
	public Ponto ponto2;
	public Ponto ponto3;
	
	
	public Triangulo(Ponto ponto1, Ponto ponto2, Ponto ponto3) {
		this.ponto1 = ponto1;
		this.ponto2 = ponto2;
		this.ponto3 = ponto3;
	}

	public Double calcularPerimetro() {
		
		Double soma = ponto1.calcularDistancia(ponto2);
		soma += ponto2.calcularDistancia(ponto3);
		soma += ponto3.calcularDistancia(ponto1);
				
		
		return  soma;			 
		
	}

}
