package Atividade2;

public class Ponto {
	public Double x;
	public Double y;
	
	
	
	public Ponto(Double x, Double y) {
		this.x = x;
		this.y = y;
	}


	public Double calcularDistancia (Ponto outroPonto) {
		
		Double d = Math.sqrt(Math.pow(x - outroPonto.x, 2)+ Math.pow(y - outroPonto.y,2));
		
		return d ;
		
		
		
	}
}
