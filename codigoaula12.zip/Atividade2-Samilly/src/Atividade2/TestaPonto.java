package Atividade2;

public class TestaPonto {

	public static void main(String[] args) {
		
		Ponto p1 = new Ponto(10.0,20.0);
		Ponto p2 = new Ponto(2.0, 5.4);
		Ponto p3 = new Ponto(1.0, 15.4);
		
		System.out.println("A distancia é :" + p1.calcularDistancia(p2));
		
		
		
		
		Triangulo t1 = new Triangulo(p1,p2,p3);
		//Triangulo t2 = new Triangulo(new Ponto(2.4,5.4),new Ponto(2.0,10.3), new Ponto(11.4,2.5));
		
		System.out.println("O perímetro do triangulo é:" +t1.calcularPerimetro());
		
	}

	
	
}
