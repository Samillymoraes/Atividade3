package q1;

import br.banco.sistema.*;

public class ContaPoupanca extends Conta{
	private Double taxaRendimento;
	
	public ContaPoupanca(Double taxaRendimento1, String titular, Double saldo) {
		super(titular, saldo);
		this.taxaRendimento = taxaRendimento1;
	}
	
	public Double calcularRendimento() {
		return this.saldo * 0.05;
	}
}
