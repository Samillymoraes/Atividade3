package q1;

import br.banco.sistema.*;

public class ContaCorrente extends Conta{
	protected  Double limite;
	private static final Double limiteMaximo = 200.0;

	public ContaCorrente (Double limite1, String titular, Double saldo) {
		super(titular, saldo);
		this.limite = limite1;

	}
	@Override
	public void sacar (Double valor) {
		if(valor > this.saldo)  {
			if((this.saldo+this.saldo) >= valor ) {
				this.limite -= valor - this.saldo;
				this.saldo = 0.0;
			} else {
				throw new Error("saldo insuficiente");
			}
		} else {
			this.saldo -= valor;
		}


	}
	@Override
	public void depositar (Double valor) {
		if(this.limite < 200) {
			Double restoDoLimite = 200 - this.limite;
			if (valor > restoDoLimite) {
				this.limite += restoDoLimite;
				this.saldo += valor - restoDoLimite;
			} else {
				this.limite += valor;
			}

		} else {
			this.saldo += valor;
		}
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString() + this.limite;
	}

}
