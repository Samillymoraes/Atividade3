package q1;

import br.banco.sistema.Conta;
public class TestaConta {
	public static void main(String[] args) {
		Conta c1 = new Conta("Samilly",20.0);
		c1.depositar(2000.0);
		System.out.println(c1.toString());
		c1.sacar(1000.0);
		System.out.println(c1.toString());
		
		ContaCorrente c2 = new ContaCorrente(100.0,"Ruan",50.0);
		c2.depositar(200.0);
		c2.sacar(280.0);
		System.out.println(c2.toString());
		
		ContaPoupanca c3 = new ContaPoupanca(20.0,"Marcos",50.0);
		c3.depositar(2000.0);
		c3.sacar(100.0);
		System.out.println(c3.toString());
		System.out.println(c3.calcularRendimento());

		
	
		
		
	}

}
