package respostas;

public class Automovel extends Terrestre {
	
	private Integer numeroDePortas;
	

	public Automovel(Integer capacidade, Integer numeroDeRodas, String cor, String placa, Integer numeroDePortas) {
		super(capacidade, numeroDeRodas, cor, placa);
		this.numeroDePortas = numeroDePortas;
	}
	
	public Integer getNumeroDePortas () {
		return numeroDePortas;
		
	}
	
	public void numeroDePortas(Integer numeroDePortas) {
		
	}
		@Override
		public String toString() {
			return "capacidade = " + this.getCapacidade() + ", Numero de rodas = " + this.getNumeroDeRodas() +
				", Cor= " + this.getCor() +  ", Placa= " + getPlaca() + ", Numero de portas= " + this.numeroDePortas;
			
		}
		
	}

