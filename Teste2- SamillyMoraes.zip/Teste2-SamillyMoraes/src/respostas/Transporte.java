package respostas;

public class Transporte {
	private Integer capacidade;
	
	
	public Transporte (Integer capacidade) {
		this.capacidade = capacidade;
		
	}
	
	public Integer getCapacidade() {
		return capacidade;
		
	}
	public Integer setCapacidade() {
		return capacidade;
		
	}
	
	public String toString() {
		return "capacidade" + this.capacidade;
		
	}
	
}
