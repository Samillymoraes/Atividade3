package respostas;

public class Terrestre extends Transporte {
	
	private Integer numeroDeRodas;
	private String cor;
	private String placa;
	

	public Terrestre(Integer capacidade, Integer numeroDeRodas, String cor, String placa) {
		super(capacidade);
		this.numeroDeRodas = numeroDeRodas;
		this.cor = cor;
		this.placa = placa;
		
	}
	
	public Integer getNumeroDeRodas () {
		return numeroDeRodas;
		
	}
	
	public void setNumeroDeRodas(Integer numeroDeRodas) {
		
	}
	
	public String getCor () {
		return cor;
		
	}
	public void setCor (String cor) {
		
	}
	
	public String getPlaca () {
		return placa;
	}
	
	public void setPlaca () {
		
	}
	@Override
	public String toString() {
		return "capacidade = " + this.getCapacidade() + "Numero De Rodas = " + this.numeroDeRodas +
			"Cor= " + this.cor +  "Placa" + placa;
		
	}
		
	}


