package Atividade3;

public class Quadrado {
	
	public Double lado;
	
	public Quadrado (Double l) {
		this.lado = l;
	}
	
	public Quadrado (double area) {
		this.lado = Math.sqrt(area);
		System.out.println(area);
	}
	
	public Double calculaPerimetro() {
		Double perimetro= (lado+lado+lado+lado);
		return perimetro;
	}
	
	public Double calculaArea () {
		Double area2 = (lado*lado);
		return area2;
	}
	
	public Double calculaApotema() {
		Double apotema = (lado/2);
		return apotema;
	}

	
}
