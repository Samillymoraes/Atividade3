package Atividade3;

public class TestaQuadrado {

	public static void main(String[] args) {
		
		double area = 5.0;
		new Quadrado (area);
		
		Double lado = 6.0;
		Quadrado l1 = new Quadrado (lado);
				
		System.out.println(l1.calculaPerimetro());
		System.out.println(l1.calculaArea());
		System.out.println(l1.calculaApotema());
		
		
	}		
}
