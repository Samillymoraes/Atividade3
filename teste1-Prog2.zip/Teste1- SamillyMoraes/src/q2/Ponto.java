package q2;

public class Ponto {
	public Double x;
	public Double y;
	
	
	public Ponto(Double novox, Double novoy) {
		this.x = novox;
		this.y = novoy;
		
//	Ponto p1 = new Ponto (0.0,0.0);	
	
	
	
	
	}

}
