package q2;

public class Circulo {
	
	public Double raio;
	public Ponto centro;
	
	
	public Circulo (Double novoR, Ponto novoC) {
		this.raio = novoR;
		this.centro = novoC;
//		this.centro = 	
							
		
	}
	public  void inflar (Double VF) {
		
		
	}
	
	public  void desinflar (Double VF) {
			
		
	}
		
		
}
	
