package q1;

public class TestaJornada {

	public static void main(String[] args) {
		
		Professor p1 = new Professor (569, "Hugo Kuribayashi");
		
		Discente d1 =  new Discente (2022336, "Samilly", 2 , 6.5, p1);
		
		Artigo a1 = new Artigo (55, "Jornada da tecnologia", d1);
		
		Apresentacao ap1 = new Apresentacao (6, "praça", "9h", a1);
		
		 System.out.println("O artigo sera apresentado com essas informaçãoes a baixo \n");
		 System.out.println("A discente sera: " +d1.nome);
		 System.out.println("Com a matrícula de número: " +d1.matricula);
		 System.out.println("Cursando o periodo: " +d1.semestre);
		 System.out.println("Com a CRG: " +d1.CRG);
		 System.out.println("O seu orientador: " +p1.nome);
		 
		 System.out.println("O artigo:  "+a1.titulo);
		 System.out.println("\nSera apresentado na:  "+ap1.local);
		 System.out.println("As: \n \n  "+ap1.horario);
		 
		 	
	
		Professor p2 = new Professor (587, "Leia");
		
		Discente d2 =  new Discente (54884554, "Maria", 5 , 8.0, p2);
		
		Artigo a2 = new Artigo (2, "Jornada pelo mundo", d2);
		
		Apresentacao ap2 = new Apresentacao (8, "sala", "10h", a2);
		
		System.out.println("\n \nO artigo sera apresentado com essas informaçãoes a baixo \n");
		System.out.println("A discente sera: " +d2.nome);
		System.out.println("Com a matrícula de número: " +d2.matricula);
		System.out.println("Cursando o periodo: " +d2.semestre);
		System.out.println("Com a CRG: " +d2.CRG);
		System.out.println("O seu orientador: " +p2.nome);
		 
		System.out.println("O artigo:  "+a2.titulo);
		System.out.println("\nSera apresentado na:  "+ap2.local);
		System.out.println("As: "+ap2.horario);
	}

}
	
