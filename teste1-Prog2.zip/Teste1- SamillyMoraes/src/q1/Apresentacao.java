package q1;

public class Apresentacao {
	
	public Integer numero;
	public String local;
	public String horario;
	public Artigo artigo;
	
	public Apresentacao (Integer novoN, String novoL, String novoH, Artigo novoA) {
		this.numero = novoN;
		this.local = novoL;
		this.horario = novoH;
		this.artigo = novoA;
		
	}

}
