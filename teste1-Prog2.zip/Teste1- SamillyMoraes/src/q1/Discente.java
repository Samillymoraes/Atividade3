package q1;

public class Discente {
	
	public Integer matricula;
	public String nome;
	public Integer semestre;
	public Double CRG;
	public Professor orientador;


	public Discente (Integer novaM, String novoN, Integer novoS, Double novoC, Professor novoO ) {
		this.matricula = novaM;
		this.nome = novoN;
		this.semestre = novoS;
		this.CRG = novoC;
		this.orientador = novoO;
		
	}
	
	/*public  void calculaCRG( ) { //VF : valor final da CRG;
		System.out.println("Informe o seu CRG" +CRG);
		
		
	}*/

}
