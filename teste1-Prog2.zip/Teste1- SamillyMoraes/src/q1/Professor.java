package q1;

public class Professor {
	
	public Integer matricula;
	public String nome;
	
	public Professor (Integer novaM, String novoN ) {
		this.matricula = novaM;
		this.nome = novoN;
				
	}

}
