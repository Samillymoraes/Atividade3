package q1;

public class Artigo {
	
	public Integer numero;
	public String titulo;
	public Discente descricao;
	
	public Artigo (Integer novoN, String novoT, Discente novaD) {
		this.numero = novoN;
		this.titulo = novoT;
		this.descricao = novaD;

	}

}
