package respostas;

public class Email {
	private String prefixo;
	private String sufixo;
	
	public Email (String email ) {
		String[] output =email.split("@");
		System.out.println("prefixo eh " +output[0]);
		System.out.println("sufixo eh @" +output[1]);
		this.prefixo= output[0];
		this.sufixo= output[1];
		
				
	}	
	public Boolean valEmail(String email) {
		return (email.contains("@"));
		
	}
	
	public String retornaEmail() {
		return (prefixo + sufixo);
				
	}

	public String setPrefixo() {
			return prefixo;
		}
		
	public String setSufixo() {
			return sufixo;
		}
		
		
}
