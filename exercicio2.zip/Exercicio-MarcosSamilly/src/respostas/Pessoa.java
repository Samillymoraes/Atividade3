package respostas;

public class Pessoa {
	private String nome;
	private Integer anoNascimento;
	private Email enderDeEmail;
	private String Pessoa;
	
	
	
	public Boolean valData() {
		if (anoNascimento>=1923 || anoNascimento <=2023) {
			return true;
		}else {return false; 
		}
	
	}
	
	public Pessoa (Integer nasc, String nome1, Email end) {
		this.anoNascimento = nasc;
		this.nome = nome1;
		this.enderDeEmail = end;
	}
	
	public Integer retornaIdade () {
		Integer idade = (anoNascimento -2023);
		return idade;
			
	}
	public String getNome() {
		return nome;
	}
	
	public Email getEnderEmail() {
		return enderDeEmail;
		
	}
	
	
	public String retornDadosPessoa( ) {
		return this.Pessoa;
		
	}
}


