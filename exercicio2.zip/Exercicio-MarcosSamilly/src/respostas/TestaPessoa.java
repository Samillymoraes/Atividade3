package respostas;

public class TestaPessoa {

	public static void main(String[] args) {
		Email e1 = ("Samillymoraes@unifesspa.edu.br");
		
		
		Pessoa p1 = new Pessoa (2005, " Samilly", e1);
		
		
		

	}

}
