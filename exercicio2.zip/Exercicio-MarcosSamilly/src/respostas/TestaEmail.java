package respostas;

public class TestaEmail {

	public static void main(String[] args) {
		Email e1 = new Email ("Samillymoraes@.com.br");
		System.out.println(e1);
		
		}
		
		

}
