package q2;

public class TestaCarro {

	public static void main(String[] args) {
		
		System.out.println("Informações sobre o carro 1");
		Pessoa p1 = new Pessoa();
		p1.setEmail("Samilly.moraes@unifesspa.edu.br");
		p1.setNome("Samilly");
		p1.setSobrenome("Ferreira Moraes");
		System.out.println("O email do propriteário é: " +p1.setEmail("Samilly.moraes@unifesspa.edu.br"));
		System.out.println("O nome do propriteário é: " +p1.setNome("Samilly"));
		System.out.println("O sobrenome do propriteário é: " +p1.setSobrenome("Ferreira Moraes"));
		
		Motor m1 = new Motor();
		m1.setPotencia(20.0);
		m1.setFabricante("Motor ltda");		
		System.out.println("A potencia do motor  desse carro é:" +m1.setPotencia(20.0));
		System.out.println("O fabricante desse carro é:" +m1.setFabricante("Motor ltda"));
		
		Carro c1 = new Carro ();
		c1.setAnoFabricacao(2020);
		c1.setMotor();
		c1.setPessoa();
		System.out.println("O ano de fabricação desse carro é:" +c1.setAnoFabricacao(2020));
		
		
		
		System.out.println("\n \n Informações sobre o carro 2");
		Pessoa p2 = new Pessoa();
		p2.setEmail("Garcia.souza@gmail.com");
		p2.setNome("Ernandes");
		p2.setSobrenome("Garcia souza");
		System.out.println("O email do propriteário é: " +p2.setEmail("Garcia.souza@gmail.com"));
		System.out.println("O nome do propriteário é: " +p2.setNome("Ernandes"));
		System.out.println("O sobrenome do propriteário é: " +p2.setSobrenome("Garcia souza"));
		
		
		Motor m2 = new Motor();
		m2.setPotencia(55.0);
		m2.setFabricante("souza&silva Ltda");		
		System.out.println("A potencia do motor  desse carro é:" +m2.setPotencia(20.0));
		System.out.println("O fabricante desse carro é:" +m2.setFabricante("Motor ltda"));
		
		
		Carro c2 = new Carro ();
		c2.setAnoFabricacao(2023);
		c2.setMotor();
		c2.setPessoa();
		System.out.println("O ano de fabricação desse carro é:" +c1.setAnoFabricacao(2023));
		
		
		
		
		
	}
}
