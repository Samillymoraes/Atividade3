package q2;

public class Motor {
	private Double potencia;
	private String fabricante;
	
	public Double getPotencia() {
		 return this.potencia;
	}
	
	public String getFabricante() {
		return this.fabricante;
	}
	
	public double setPotencia(Double potencia) {
		 return this.potencia= potencia;
	}
	
	public String setFabricante(String fabricante) {
		return this.fabricante=fabricante;
	}


}
