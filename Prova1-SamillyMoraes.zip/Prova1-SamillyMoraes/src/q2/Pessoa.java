package q2;

public class Pessoa {
	private String nome;
	private String sobrenome;
	private String email;
	
	public String getEmail( ) {
		return this.email  ;
		
	}
	
	public String getNome() {
		return this.nome;
			
	}
	
	public String getSobrenome() {
		return this.sobrenome;
	}
	
	public String setEmail(String email ) {
		return this.email = email ;
		
	}
	
	public String setNome(String nome) {
		return this.nome=nome;
			
	}
	
	public String setSobrenome(String sobrenome) {
		return this.sobrenome=sobrenome;
	}
	

}
