package q2;

public class Carro {
	
	private Integer anoFabricacao;
	private Motor motor;
	private Pessoa proprietario;
	
	public Integer getAnoFabricacao() {
		return this.anoFabricacao ;
		
	}
	
	public Motor getMotor() {
		return this.motor;
	
	}
	
	public Pessoa getPessoa () {
		return this.proprietario;
		
	}
	public Integer setAnoFabricacao(Integer anofabricacao) {
		return this.anoFabricacao = anofabricacao ;
		
	}
	
	public Motor setMotor() {
		return this.motor;
	
	}
	
	public Pessoa setPessoa () {
		return this.proprietario;
		
	}

	
	

}
