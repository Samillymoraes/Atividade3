package q1;

public class Navio {
	
	private String fabricante;
	private Double velocidadeAtual;
	private static Integer contador = 0;
	
	public Navio ( String novoFabricante) {
		this.fabricante = novoFabricante;
		this.velocidadeAtual = 0.0;
		Navio.contador +=1;
		
	}
	
	public Navio (String novoFabricante, Double novaVelocidade) {
		this.fabricante= novoFabricante;
		this.velocidadeAtual = novaVelocidade;
		Navio.contador +=1;
		
	}
	
	public void aumentarVelocidade() {
		this.velocidadeAtual += 1;
		
	}
	
	public void reduzirVelocidade() {
		this.velocidadeAtual-=1;
		
	}
	
	public static Integer getContador() {
		return Navio.contador;
				
	}
	public String getFabricante () {
		return this.fabricante;
		
	}

}
