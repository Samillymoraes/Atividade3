package exercicio;

public class Carro {
	
	public String cor ;
	public String modelo ;
	public Double velocidadeAtual ;
	public Double velocidadeMaxima ;
	public Motor motor ;
	
	public Carro() {
		this.cor = "Branco";
		this.modelo= "Gol";
		this.velocidadeAtual = 0.0;
		this.velocidadeMaxima = 180.0;
		this.motor = new Motor();   
		
	}
	
	public Carro(String cor, String modelo, Motor novo) {
		cor=cor ;
		this.modelo = "SW4";
		this.motor = novo;
		
		
	}
	
	public void liga ()	{
		
	}

	public void acelera (Double qtd) {
		
	}

	public int pegaMarcha () {
		

		
		return 1;
	}
}
