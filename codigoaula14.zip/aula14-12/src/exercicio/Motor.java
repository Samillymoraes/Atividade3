package exercicio;

public class Motor {
	public double potencia = 1000.0;
	public String tipo = "16V"; //aqui ele fez um new string (), java já definiu sem precisar exemplificar.
	public boolean taLigado = false;
	
	public Motor () {
		/*this.potencia = 1000.0;
		this.tipo = "16V";
		this.taLigado = false;*/ //poderia ser assim também,  sem exemplificar os valores dos atributos no topico.
		
	} //para poder continuar com os valores primitivos;
	
	public Motor(double novaPotencia, String novoTipo) {
		
		this.potencia = novaPotencia;
		this.tipo = novoTipo;
		
		
	}
	
	
}
