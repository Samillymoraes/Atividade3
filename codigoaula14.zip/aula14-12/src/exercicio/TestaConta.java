package exercicio;

public class TestaConta {
	
	public static void main (String[] args) {
		
	/*	Motor m1 = new Motor (2000.0, "8v");
		System.out.println(m1.taLigado );
		System.out.println(m1.tipo );
		System.out.println(m1.potencia  );
		
		Motor m2 = new Motor();
		System.out.println(m2.taLigado );
		System.out.println(m2.tipo );
		System.out.println(m2.potencia );  */
		
		// criar um metodo construtor para a classe, caso eu queira um motor com valor diferente.
		
		Carro c1 = new Carro ();
		System.out.println(c1.cor);
		System.out.println(c1.modelo);
		System.out.println(c1.velocidadeAtual);
		System.out.println(c1.velocidadeMaxima);
		System.out.println(c1.motor);
		
		Motor novoMotor = new Motor();
		Carro c2 = new Carro ("cinza", "HRV", novoMotor);
	
	}

}
